For asking questions, visit:

* [Stack Overflow](https://stackoverflow.com/questions/tagged/go+visual-studio-code)
* [Gophers Slack](https://gophers.slack.com) - Use the [invite app](https://invite.slack.golangbridge.org/) for access.
	* `#vscode` channel for general questions
	* `#vscode-dev` channel for extension development-related questions
