package disabledInitFuncFirstCheck

func a() {}

func init() {}
