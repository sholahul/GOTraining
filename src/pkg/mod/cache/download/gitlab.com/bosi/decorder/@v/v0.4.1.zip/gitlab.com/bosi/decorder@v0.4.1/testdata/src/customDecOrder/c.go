package customDecOrderAll

var _ = 1

const ca = 1 // want "const must not be placed after var \\(desired order: const,var\\)"
