package main

type foo struct{}

// ToDoc method.
func (f foo) ToDoc() int {
	return 0
}
