package msgpack

// Version is the current release version.
func Version() string {
	return "5.4.1"
}
