package checker_test

import "fmt"

func negativeHelloworld() {
	fmt.Println("Hello")
	fmt.Println("Shiny")
	fmt.Println("World")
}
