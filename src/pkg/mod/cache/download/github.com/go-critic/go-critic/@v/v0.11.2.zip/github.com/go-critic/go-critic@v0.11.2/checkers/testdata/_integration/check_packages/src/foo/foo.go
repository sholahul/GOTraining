package foo

func sliceIdentity(xs []int) []int {
	return xs[:]
}
