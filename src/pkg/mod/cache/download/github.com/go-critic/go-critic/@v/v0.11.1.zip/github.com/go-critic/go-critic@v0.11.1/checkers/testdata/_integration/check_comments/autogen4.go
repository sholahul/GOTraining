// This file was automatically generated.
package foo
