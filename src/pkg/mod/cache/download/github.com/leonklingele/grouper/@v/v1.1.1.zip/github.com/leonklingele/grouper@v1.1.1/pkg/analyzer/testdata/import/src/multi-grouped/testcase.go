package testcase

import (
	"fmt"
	"log"
)

func dummy() { fmt.Println("dummy"); log.Println("dummy") }
