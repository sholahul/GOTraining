package testcase

const (
	a = "a"
)

func dummy() {
	const (
		_ = "ignore1"
	)
}
