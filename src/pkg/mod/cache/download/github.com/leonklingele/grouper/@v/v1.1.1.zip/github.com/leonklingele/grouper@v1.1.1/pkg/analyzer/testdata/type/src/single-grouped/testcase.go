package testcase

type (
	a string
)

func dummy() {
	type (
		_ string
	)
}
