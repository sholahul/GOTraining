package testcase

import (
	"fmt"
)

func dummy() { fmt.Println("dummy") }
