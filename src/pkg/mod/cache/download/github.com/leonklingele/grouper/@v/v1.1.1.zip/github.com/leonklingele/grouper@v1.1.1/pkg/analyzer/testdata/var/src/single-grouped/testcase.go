package testcase

var (
	a = "a"
)

func dummy() {
	var (
		_ = "ignore1"
	)
}
