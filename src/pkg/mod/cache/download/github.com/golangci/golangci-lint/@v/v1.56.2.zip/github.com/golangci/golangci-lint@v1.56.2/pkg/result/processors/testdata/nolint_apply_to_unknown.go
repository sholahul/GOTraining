package testdata

func bar() {
	_ =  0 //nolint: foobar
}
