# Hard Fork of gofmt

2022-08-31: Sync with go1.18.5
2023-10-04: Sync with go1.19.13
2023-10-04: Sync with go1.20.8
