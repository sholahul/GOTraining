package main

import "fmt"

func foo() {
	testString1 := "test"
	testString2 := "test"

	testInt1 := 123
	testInt2 := 123

	fmt.Println(testString1, testString2, testInt1, testInt2)
}
