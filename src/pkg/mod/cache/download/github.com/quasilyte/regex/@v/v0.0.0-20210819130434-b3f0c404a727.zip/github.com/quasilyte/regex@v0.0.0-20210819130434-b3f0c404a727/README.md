# regex - [regular expression](https://en.wikipedia.org/wiki/Regular_expression) libraries for Go

## Packages

* [syntax](/syntax) - regexp parser and AST definitions
