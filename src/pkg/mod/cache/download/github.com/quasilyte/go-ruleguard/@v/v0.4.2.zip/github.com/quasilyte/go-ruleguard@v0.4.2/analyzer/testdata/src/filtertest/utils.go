package filtertest

func objectTest(args ...interface{})       {}
func typeTest(args ...interface{})         {}
func pureTest(args ...interface{})         {}
func constTest(args ...interface{})        {}
func textTest(args ...interface{})         {}
func parensFilterTest(args ...interface{}) {}
func importsTest(args ...interface{})      {}
func fileTest(args ...interface{})         {}
func nodeTest(args ...interface{})         {}
func lineTest(args ...interface{})         {}
func valueTest(args ...interface{})        {}

func random() int {
	return 42
}
