package revive

func getBool() bool { return false }
