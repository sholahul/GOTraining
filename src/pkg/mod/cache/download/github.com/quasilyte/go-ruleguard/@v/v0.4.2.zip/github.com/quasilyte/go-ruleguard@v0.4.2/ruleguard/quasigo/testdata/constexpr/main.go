package main

const one int = 1

func main() {
	x := one
	println(x)
	println(one)
	println(one + 1 + one)
}
